#pragma once
#include "utils.hpp"
#include "Block.hpp"
#include "Disk.hpp"
#include "Unit.hpp"
#include "Request.hpp"
#include "Object.hpp"

Unit unit[MAX_DISK_NUM][MAX_DISK_SIZE];
Request request[MAX_REQUEST_NUM];
Disk disk[MAX_DISK_NUM];
Object object[MAX_OBJECT_NUM];
Block block[MAX_OBJECT_NUM][MAX_OBJECT_SIZE];

int T, M, N, V, G;
int global_state[3 * MAX_TAG_NUM][MAX_REQUEST_NUM / FRE_PER_SLICING + 10];
int quan_test;
void timestamp_action()
{
    int timestamp;
    scanf("%*s%d", &timestamp);
    printf("TIMESTAMP %d\n", timestamp);
    fflush(stdout);
}

void delete_action()
{
    int n_delete;
    int abort_num = 0;
    static int _id[MAX_OBJECT_NUM];
    std::set<int> abort_set; // ��¼ɾ������
    scanf("%d", &n_delete);
    for (int i = 1; i <= n_delete; i++) {
        scanf("%d", &_id[i]);
    }

    for (int i = 1; i <= n_delete; i++) {
        int id = _id[i];
        auto [num, set_] = object[id].deleted();
        abort_num += num;
        abort_set.insert(set_.begin(), set_.end());
    }
    printf("%d\n", abort_num);
    for (int rd_id : abort_set) {
        printf("%d\n", rd_id);
    }
    fflush(stdout);
}

void write_action()
{
    int n_write;
    scanf("%d", &n_write);
    for (int i = 1; i <= n_write; i++) {
        int id, size, tag;
        scanf("%d%d%d", &id, &size, &tag);
        object[id].set(size, tag);

        // ��ӡ������
        printf("%d\n", id);
        for (int j = 1; j <= REP_NUM; j++) {
            int dk_id = (id + j) % N + 1;

            // �ҵ����Բ���Ĵ���id
            int first_empty = disk[dk_id].add_object(id, size);
            while (!first_empty) {
                dk_id = (dk_id % N) + 1;
                first_empty = disk[dk_id].add_object(id, size);
            }
            printf("%d", dk_id);
            // Ѱ���ռ���������λ��
            int curcurrent_write_num = 0;
            std::vector<int> block_pos;
            for (int k = first_empty; k <= V; k++) {
                if (!unit[dk_id][k].is_exist) {
                    // ���µ�Ԫ״̬
                    printf(" %d", k);
                    unit[dk_id][k].add_block(id, ++curcurrent_write_num);
                    block_pos.push_back(k);
                }
                if (curcurrent_write_num == size) {

                    // ��λ�ñ��浽������
                    object[id].set_pos(j, block_pos, dk_id);
                    // ���µ�һ����λ��
                    while (k <= V && !unit[dk_id][k].is_exist) k++;
                    disk[dk_id].first_empty = k;

                    break;
                }
            }
            printf("\n");
        }
    }

    fflush(stdout);
}

// ������λ���Ƿ��м�ֵ
bool check_value(int dk_id , int pos)
{
    int oj_id = unit[dk_id][pos].object_id;
    int bk_id = unit[dk_id][pos].block_order;
    return block[oj_id][bk_id].check();
}

std::vector<int> do_read(int dk_id) {
    std::vector<int> complete_id;
    int pos = disk[dk_id].point;
    int oj_id = unit[dk_id][pos].object_id;
    int bk_id = unit[dk_id][pos].block_order;
    std::set<int> temp_set = block[oj_id][bk_id].requested_id_block;
    for (int rq_id : temp_set) {

        // ��������ɵ�����ÿһ��
        if (request[rq_id].readed(bk_id)) {
            complete_id.push_back(rq_id);
            object[oj_id].requested_id.erase(rq_id);
        }
        block[oj_id][bk_id].requested_id_block.erase(rq_id);
    }
    disk[dk_id].point = (disk[dk_id].point % V) + 1;
    disk[dk_id].last_point_status = READ;
    printf("r");
    fflush(stdout);
    return complete_id;
}

void read_action()
{
    int n_read;
    int request_id, object_id;
    scanf("%d", &n_read);
    for (int i = 1; i <= n_read; i++) {
        scanf("%d%d", &request_id, &object_id);

        // ���Ӳ���������
        object[object_id].add_request(request_id);
    }
    int complete = 0;
    std::vector<int> complete_id;
    for (int i = 1; i <= N; i++) {

        // ��һ����飬�鿴��JUMP����PASS
        int j;
        bool ok = false;
        for (j = 0; j <= G; j++) {
            if (check_value(i, disk[i].point + j)) {
                ok = true;
                break;
            }
        }

        // �ô���û�������
        if (ok == false) {
            // ���ô����Ƿ����м�ֵ�Ŀ飬�����jump��ȥ
            // û�иô����Թ�
            bool exist_value = false;
            int k;
            for (k = 1; k <= V; k++)
            {
                if (check_value(i, k)) {
                    exist_value = true;
                    break;
                }
            }
            if (exist_value)
            {
                printf("j %d\n", k);
                fflush(stdout);
                disk[i].point = k;
                disk[i].last_point_status = JUMP;
            }
            else {
                // ÿ��ֵ�Ͳ���
                printf("#\n");
                fflush(stdout);
            }
        }
        else { // �ô����л������׼����tokens�������
            while (disk[i].rest_tokens > 0) {
                while (disk[i].rest_tokens > 0 && !check_value(i, disk[i].point)) {
                    disk[i].last_point_status = PASS;
                    disk[i].rest_tokens--;
                    disk[i].last_take_tokens = 1;
                    disk[i].point = (disk[i].point % V) + 1;
                    printf("p");
                    fflush(stdout);
                }
                if (disk[i].rest_tokens == 0) {
                    break;
                }
                int cur_take_tokens = READ_TAKE_TOKENS;
                if (disk[i].last_point_status == READ) {
                    cur_take_tokens = std::max(16, static_cast<int>(std::ceil(disk[i].last_take_tokens * 0.8)));
                }

                if (disk[i].rest_tokens >= cur_take_tokens)
                {
                    disk[i].rest_tokens -= cur_take_tokens;
                    std::vector<int> temp_vector = do_read(i);
                    complete_id.insert(complete_id.begin(), temp_vector.begin(), temp_vector.end());
                    disk[i].last_take_tokens = cur_take_tokens;
                }
                else {
                    break;
                }
                
            }
            printf("#\n");
            fflush(stdout);
        }
        disk[i].rest_tokens = G;

    }
    printf("%d\n", complete_id.size());
    fflush(stdout);
    for (int rq_id : complete_id) {
        printf("%d\n", rq_id);
        fflush(stdout);
    }

}


int main()
{
    scanf("%d%d%d%d%d", &T, &M, &N, &V, &G);
    
    for (int i = 1; i <= N; i++) {
        disk[i].set(V, G);
    }
    //��ȡȫ��״̬
    for (int i = 1; i <= 3 * M; i++) {
        for (int j = 1; j <= (T - 1) / FRE_PER_SLICING + 1; j++) {
            scanf("%d", &global_state[i][j]);
        }
    }

    put_ok();
    for (int t = 1; t <= T + EXTRA_TIME; t++) {
        timestamp_action();
        delete_action();
        write_action();
        read_action();
    }

    return 0;
}